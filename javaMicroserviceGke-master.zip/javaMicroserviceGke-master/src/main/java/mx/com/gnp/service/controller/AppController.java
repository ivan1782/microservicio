package mx.com.gnp.service.controller;

import java.util.concurrent.atomic.AtomicLong;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import mx.com.gnp.service.exception.InvalidNameException;
import mx.com.gnp.service.model.Farewell;
import mx.com.gnp.service.model.Greeting;
import mx.com.gnp.service.model.HttpStatus;

/**
 * Clase controller para aplicación microservicio java.
 * 
 * @author jsetien
 *
 */
@RestController
@RequestMapping("/template")
@Slf4j
public class AppController {

	/** Template para saludo. */
	private static final String TEMPLATE_GREETING = "Hello, %s!";

	/** Template para despedida. */
	private static final String TEMPLATE_FAREWELL = "Bye, %s!";

	/** Contador para saludo. */
	private final AtomicLong greetingCounter = new AtomicLong();

	/** Contador para despedida. */
	private final AtomicLong farewellCounter = new AtomicLong();

	/** Default name. */
	private static final String DEFAULT_NAME = "Stranger";

	/**
	 * Rest hello world.
	 * 
	 * @param name
	 *            El nombre a saludar.
	 * @return Un saludo.
	 */
	@ApiOperation(code = HttpStatus.OK, value = "Envía un saludo a quien se le solicite", 
			produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ApiResponses(value = { @ApiResponse(code = HttpStatus.OK, message = "El saludo ha sido enviado "),
			@ApiResponse(code = HttpStatus.BAD_REQUEST, message = "El saludo no es válido") })
	@ResponseStatus(value = org.springframework.http.HttpStatus.ACCEPTED)
	@GetMapping(value = "/greeting", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public final Greeting sayHello(
			@RequestParam(name = "name", required = false, defaultValue = DEFAULT_NAME) final String name) {
		log.warn("Esto es una advertencia, alguien llega...");
		log.info("Se validará el nombre de la persona " + name);
		if (name.length() == 1) {
			log.debug("El nombre de la persona recibida es -> " + name);
			log.error("El nombre de la persona es inválido ya que no puede tener solo 1 letra");
			throw new InvalidNameException("Nombre inválido -> " + name);
		}
		log.info("El nombre de la persona " + name + " se ha validado exitosamente");
		log.info("Enviando saludo");
		return new Greeting(greetingCounter.incrementAndGet(), String.format(TEMPLATE_GREETING, name));
	}

	/**
	 * Rest para enviar una despedida.
	 * 
	 * @param name
	 *            El nombre a despedir.
	 * @return Una despedida.
	 */
	@ApiOperation(code = HttpStatus.OK, value = "Se despide de alguna persona", 
			produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ApiResponses(value = { @ApiResponse(code = HttpStatus.OK, message = "Hemos dicho Adios! "),
			@ApiResponse(code = HttpStatus.BAD_REQUEST, message = "No se puede decir Adios, nombre inválido") })
	@ResponseStatus(value = org.springframework.http.HttpStatus.ACCEPTED)
	@GetMapping(value = "/farewell", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public final Farewell sayGoodBye(
			@RequestParam(name = "name", required = false, defaultValue = DEFAULT_NAME) final String name) {		
		log.warn("Esto es una advertencia, alguien se va...");
		log.info("Se validará el nombre de la persona -> " + name);
		if (name.length() == 1) {
			log.debug("El nombre de la persona recibida es -> " + name);
			log.error("El nombre de la persona es inválido ya que no puede tener solo 1 letra");
			throw new InvalidNameException("Nombre inválido -> " + name);
		}
		log.info("El nombre de la persona " + name + " se ha validado exitosamente");
		log.info("Enviando despedida");
		return new Farewell(farewellCounter.incrementAndGet(), String.format(TEMPLATE_FAREWELL, name));
	}
}
