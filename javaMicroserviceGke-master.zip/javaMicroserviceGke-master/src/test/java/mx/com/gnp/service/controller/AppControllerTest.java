package mx.com.gnp.service.controller;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import mx.com.gnp.service.exception.InvalidNameException;
import mx.com.gnp.service.model.Farewell;
import mx.com.gnp.service.model.Greeting;

/**
 * @author jsetien
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class AppControllerTest {

	/***/
	@Autowired
	private AppController appController;

	/***/
	private static final String NAME = "Pedro";

	/***/
	private static final String INVALID_NAME = "L";

	/***/
	private static final String GREETING = "Hello, Pedro!";

	/***/
	private static final String FAREWELL = "Bye, Pedro!";

	/**
	 * Los asserts siempre son necesarios para validar la información que nos
	 * regresa y así poder evaluar el resultado del método que estamos probando
	 */
	@Test
	public final void sayHelloTest() {

		Greeting greeting = this.appController.sayHello(NAME);

		Assert.assertEquals(1, greeting.getId());
		Assert.assertEquals(GREETING, greeting.getContent());

	}

	/**
	 * En caso de esperar una excepción la cachamos de esta forma. Recuerden nunca
	 * poner un try - catch en una prueba ya que puede haber falsos positivos.
	 */
	@Test(expected = InvalidNameException.class)
	public final void sayHelloInvalidName() {

		this.appController.sayHello(INVALID_NAME);

	}

	@Test
	public final void sayGoodbyeTest() {

		Farewell farewell = this.appController.sayGoodBye(NAME);

		Assert.assertEquals(1, farewell.getId());
		Assert.assertEquals(FAREWELL, farewell.getContent());

	}

	@Test(expected = InvalidNameException.class)
	public final void sayGoodByeInvalidName() {

		this.appController.sayGoodBye(INVALID_NAME);

	}
}
