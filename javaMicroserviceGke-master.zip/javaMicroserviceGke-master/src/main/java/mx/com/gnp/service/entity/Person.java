package mx.com.gnp.service.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author jsetien
 *
 */
@Entity
@Table(name = "PERSON")
public class Person {

	/**Id.*/
	@Id
	@Column(name = "ID_PERSON")
	private Long id;

	/**Nombre.*/
	@Column(name = "NAME")
	private String name;

	/**Apellido.*/
	@Column(name = "LASTNAME")
	private String lastname;

	/**Edad.*/
	@Column(name = "AGE")
	private Short age;

	/**
	 * Constructor requerido por JPA.
	 */
	public Person() {
		//Empty public Constructor
	}

	/**
	 * Constructor.
	 * 
	 * @param id
	 *            El id de la persona.
	 * @param name
	 *            El nombre de la persona
	 * @param lastname
	 *            El apellido de la persona
	 * @param age
	 *            La edad de la persona
	 */
	public Person(final Long id, final String name, final String lastname, final Short age) {
		this.id = id;
		this.name = name;
		this.lastname = lastname;
		this.age = age;

	}

	/**
	 * @return the id
	 */
	public final Long getId() {
		return id;
	}

	/**
	 * @return the name
	 */
	public final String getName() {
		return name;
	}

	/**
	 * @return the lastname
	 */
	public final String getLastname() {
		return lastname;
	}

	/**
	 * @return the age
	 */
	public final Short getAge() {
		return age;
	}
	
}
