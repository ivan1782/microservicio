package mx.com.gnp.service.repository;

import java.util.Optional;

import javax.persistence.EntityManager;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import mx.com.gnp.service.entity.Person;

/**
 * @author jsetien
 *
 */
@RunWith(SpringRunner.class)
@Transactional
@DataJpaTest
@SqlGroup(value = { @Sql(scripts = "/script/schema.sql", executionPhase = ExecutionPhase.BEFORE_TEST_METHOD),
		@Sql(scripts = "/script/data.sql", executionPhase = ExecutionPhase.BEFORE_TEST_METHOD) })
@ActiveProfiles("test")
public class PersonRepositoryTest {

	/***/
	@Autowired
	private PersonRepository personRepository;

	/***/
	private Person person;

	/***/
	private static final Long EXISTING_PERSON_ID = 1L;

	/***/
	private static final String EXISTING_PERSON_NAME = "Pedro";

	/***/
	private static final String EXISTING_PERSON_LASTNAME = "López";

	/***/
	private static final Short EXISTING_PERSON_AGE = (short) 20;

	/***/
	private static final Long ID = 2L;

	/***/
	private static final String NAME = "José";

	/***/
	private static final String LASTNAME = "Pérez";

	/***/
	private static final Short AGE = (short) 20;

	/***/
	@Autowired
	private EntityManager entityManager;

	@Before
	public final void initPerson() {

		this.person = new Person(ID, NAME, LASTNAME, AGE);

	}

	@Test
	public final void savePerson() {

		// Almacena a la persona
		this.personRepository.save(person);

		// Recupera a la persona
		Optional<Person> person = this.personRepository.findById(ID);

		// Valida el registro
		Assert.assertEquals(ID, person.get().getId());
		Assert.assertEquals(NAME, person.get().getName().trim());
		Assert.assertEquals(LASTNAME, person.get().getLastname().trim());
		Assert.assertEquals(AGE, person.get().getAge());

		entityManager.flush();

	}

	@Test
	public final void updatePerson() {

		Optional<Person> record = this.personRepository.findById(EXISTING_PERSON_ID);

		// Valida la información inicial
		Assert.assertEquals(EXISTING_PERSON_ID, record.get().getId());
		Assert.assertEquals(EXISTING_PERSON_NAME, record.get().getName().trim());
		Assert.assertEquals(EXISTING_PERSON_LASTNAME, record.get().getLastname().trim());
		Assert.assertEquals(EXISTING_PERSON_AGE, record.get().getAge());

		// Actualiza a la persona
		Person updatedPerson = new Person(EXISTING_PERSON_ID, NAME, LASTNAME, AGE);
		this.personRepository.save(updatedPerson);

		// Recupera a la persona que se inserta en la bd en el script inicial
		Optional<Person> updatedRecord = this.personRepository.findById(EXISTING_PERSON_ID);

		// Valida el registro
		Assert.assertEquals(EXISTING_PERSON_ID, updatedRecord.get().getId());
		Assert.assertEquals(NAME, updatedRecord.get().getName().trim());
		Assert.assertEquals(AGE, updatedRecord.get().getAge());

		entityManager.flush();

	}

	@Test
	public final void deletePerson() {

		Optional<Person> record = this.personRepository.findById(EXISTING_PERSON_ID);

		// Valida la información inicial
		Assert.assertEquals(EXISTING_PERSON_ID, record.get().getId());
		Assert.assertEquals(EXISTING_PERSON_NAME, record.get().getName().trim());
		Assert.assertEquals(EXISTING_PERSON_LASTNAME, record.get().getLastname().trim());
		Assert.assertEquals(EXISTING_PERSON_AGE, record.get().getAge());

		// Actualiza a la persona
		Person updatedPerson = new Person(EXISTING_PERSON_ID, NAME, LASTNAME, AGE);
		this.personRepository.delete(updatedPerson);

		// Recupera a la persona que se inserta en la bd en el script inicial
		Optional<Person> deletedRecord = this.personRepository.findById(EXISTING_PERSON_ID);

		Assert.assertTrue(!deletedRecord.isPresent());

		entityManager.flush();

	}

}
