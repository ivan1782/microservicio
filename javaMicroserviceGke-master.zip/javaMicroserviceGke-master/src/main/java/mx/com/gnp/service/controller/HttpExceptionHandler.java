package mx.com.gnp.service.controller;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import lombok.extern.slf4j.Slf4j;
import mx.com.gnp.service.exception.InvalidNameException;

/**
 * @author jsetien
 *
 */
@RestControllerAdvice
@Slf4j
public class HttpExceptionHandler {

	/**
	 * Maneja la excepción RuntimeException que se lanza al mandar.
	 * saludos a un nombre inválido
	 */
	@ResponseStatus(value = org.springframework.http.HttpStatus.BAD_REQUEST, 
			reason = "Invalid name")
	@ExceptionHandler(InvalidNameException.class)
	public final void badRequestDuplicatedRecipients() {
		log.debug("Saludo inválido");
	}
}
